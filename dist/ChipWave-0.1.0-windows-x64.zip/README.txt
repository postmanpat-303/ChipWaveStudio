ChipWave Tracker 0.1.0 (first runnable version) - Windows x64
==============================================================
GPL-3.0-or-later - https://github.com/postmanpat-303/ChipWaveTracker

Run: double-click ChipWave.exe (no install needed; single self-contained exe).
Windows SmartScreen may warn because the exe is not code-signed:
"More info" -> "Run anyway".

It opens the first-run demo (psy kick, hats, rolling bass at 145 BPM).
Press SPACE to play / stop.

Keys (press "? Keys" in the toolbar for the full list)
  Arrows, PgUp/PgDn, Home/End    move (Ctrl+Home/End = first/last block)
  Tab / Shift+Tab                next / previous channel
  Z S X D C V G B H N J M        notes C..B,  Q 2 W 3 E R 5 T 6 Y 7 U I 9 O 0 P = octave up
  1                              note off
  F1..F8                         base octave
  0-9 A-F                        hex in instrument / volume / effect columns
  Delete / Backspace / Insert    clear / pull up / push down
  Space / Enter / Ctrl+Enter     play song / play block / play from row
  Esc                            edit mode on/off
  Ctrl+Z / Ctrl+Y                undo / redo
  Ctrl +/-  (Shift = octave)     transpose channel
  F9 / F10                       mute / solo channel
  Ctrl+N / Ctrl+O / Ctrl+S       new / open / save .cwt   (Ctrl+Shift+S = save as)
  Ctrl+E                         export WAV

Effects: 01/02 slide up/down, 09 speed, 0C set volume, 0D volume slide,
0F tempo (0F00 = pattern break).

Instruments: the left panel lists the factory psytrance/alien synth sounds;
select one to edit oscillator, filter (LP/HP/BP, cutoff, resonance), envelope.
Import WAV samples with "Import WAV..." or drag .wav files onto the window.
Theme: "Dark (default)" or "Amiga (Workbench Gradient)" in the toolbar.

Command line:
  ChipWave.exe --self-test [out.wav]   render the demo, check it is not silent
  ChipWave.exe --render demo out.wav   render the demo (or a .cwt) to WAV
  ChipWave.exe --version
